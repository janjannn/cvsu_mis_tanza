

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-9">
                                Quarterly Report Form
                            </div>
                        </div>
                    </div>
                    <!-- 
                    --------------------------------------------------------Curriculum----------------------------------------
                    -->
                    <?php echo csrf_field(); ?>
                    
                    <?php if($userDesignation == "Curriculum" || $userDesignation == "Admin"): ?>
                        <div class="card-body">
                            <div class="card">
                                <div class="card-header">
                                    I. Curriculum
                                </div>
                                <div class="card-body">
                                    <br>
                                    <h6 class="card-title">&nbsp&nbsp&nbspA. Accreditation</h6>
                                    <table id="IA" class="table">
                                        <thead>
                                            <th>Program</th>
                                            
                                            <th>Visit Dates</th>
                                            <th>Level Applied</th>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $program_IA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accreditation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($accreditation->program); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($accreditation->date); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($accreditation->level); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <br>
                                    <h6 class="card-title">&nbsp&nbsp&nbspB. Government Recognition</h6>
                                    <table id="IB" class="table">
                                        <thead>
                                            <th>Program with CoPC</th>
                                            <th>Date of Certificate of Compliance Received</th>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $program_IB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $government): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($government->program); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($government->date); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <br>
                                    <h6 class="card-title">&nbsp&nbsp&nbspC. Licensure</h6>
                                    <table id="IC" class="table">
                                        <thead>
                                            <th class="align-middle">Licensure Examination</th>
                                            <th>CvSU Passing Percentage <br> (First Time Takers)</th>
                                            <th>National Passing Percentage <br> (First Time Takers)</th>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $program_IC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licensure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($licensure->examination); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($licensure->cvsu); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($licensure->national); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>


                     <!-- 
                    --------------------------------------------------OSAS-----------------------------------------------
                    -->
                    <?php if($userDesignation == "OSAs" || $userDesignation == "Admin"): ?>
                    <div class="card-body">
                        <div class="card">
                            <div class="card-header">
                                II. Student Profile
                            </div>
                            <div class="card-body">
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspA. Enrolment</h6>
                                <table id="IIA" class="table">
                                    <thead>
                                        <th>Program</th>
                                        <th>Major</th>
                                        <th>Number of Enrollee</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $program_IIA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrolment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                    <td>
                                                        <?php echo e($enrolment->program); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($enrolment->major); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($enrolment->enrollee); ?>

                                                    </td>
                                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspB. Foreign Students</h6>
                                <table id="IIB" class="table">
                                    <thead>
                                        <th>Name</th>
                                        <th>Nationality</th>
                                        <th>Program</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $name_IIB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foreign_students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($foreign_students->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($foreign_students->nationality); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($foreign_students->program); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspC. Graduates</h6>
                                <table id="IIC" class="table">
                                    <thead>
                                        <th>Program</th>
                                        <th>Number of Graduates</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $program_IIC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graduates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($graduates->program); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($graduates->graduates); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspD. Scholarships</h6>
                                <table id="IID" class="table">
                                    <thead>
                                        <th>Program</th>
                                        <th>Number of Scholars</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <?php $__currentLoopData = $program_IID; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scholarships_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e('',$academic = $scholarships_student->academic); ?>

                                                        <?php echo e('',$assistance = $scholarships_student->assistance); ?>

                                                        <?php echo e('',$government = $scholarships_student->government); ?>

                                                        <?php echo e('',$service = $scholarships_student->service); ?>

                                                        <?php echo e('',$private = $scholarships_student->private); ?>  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td>Academic Scholarship</td>
                                            <td>
                                                <?php echo e($academic); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Financial Assistance</td>
                                            <td>
                                                <?php echo e($assistance); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Government</td>
                                            <td>
                                                <?php echo e($government); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Service Scholarship</td>
                                            <td>
                                                <?php echo e($service); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Private Scholarship</td>
                                            <td>
                                                <?php echo e($private); ?>

                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspE. Recognition and Awards of Students</h6>
                                <table id="IIE" class="table">
                                    <thead>
                                        <th>Name of Recognition/Award</th>
                                        <th>Granting Agency/Institution</th>
                                        <th>Grantee</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $award_IIE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recognition_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($recognition_student->award); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($recognition_student->agency); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($recognition_student->grantee); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspF. National Competency for Students</h6>
                                <table id="IIF" class="table">
                                    <thead>
                                        <th>Program</th>
                                        <th>Type of National Competency</th>
                                        <th>Number of Students with Certificates</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $program_IIF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competency_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($competency_student->program); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($competency_student->competency); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($competency_student->students); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- 
                    -----------------------------------------------------Faculty ------------------------------------------------------
                    -->
                    <div class="card-body">
                        <div class="card">
                            <div class="card-header">
                                III. Faculty and Staff Profile
                            </div>
                            <div class="card-body">
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspA. Seminars and Trainings</h6>
                                <table id="IIIA" class="table">
                                    <thead>
                                        <th>Type</th>
                                        <th>Title of Seminar/ Training/ Workshop</th>
                                        <th>Venue</th>
                                        <th>Date</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $type_IIIA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($seminar->type); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($seminar->title); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($seminar->venue); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($seminar->date); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspB. Faculty Recognition and Awards</h6>
                                <table id="IIIB" class="table">
                                    <thead>
                                        <th>Type</th>
                                        <th>Award/Recognition</th>
                                        <th>Granting Agency/Institution</th>
                                        <th>Venue</th>
                                        <th>Date Received</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $type_IIIB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recognition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($recognition->type); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($recognition->award); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($recognition->agency); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($recognition->venue); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($recognition->date); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspC. National Competency</h6>
                                <table id="IIIC" class="table">
                                    <thead>
                                        <th>Type of National Competency</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $type_IIIC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($competency->type); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspD. Paper Presentation</h6>
                                <table id="IIID" class="table">
                                    <thead>
                                        <th>Type</th>
                                        <th>Name of Conference</th>
                                        <th>Title of the Study Presented</th>
                                        <th>Venue</th>
                                        <th>Date</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $type_IIID; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presentation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($presentation->type); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($presentation->conference); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($presentation->title); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($presentation->venue); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($presentation->date); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspE. Publication<h6>
                                <table id="IIIE" class="table">
                                    <thead>
                                        <th>Title of the Published Study</th>
                                        <th>Journal Article</th>
                                        <th>Publisher</th>
                                        <th>Volume Number/ISSN Number</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $title_IIIE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($publication->title); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($publication->article); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($publication->publisher); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($publication->number); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 
                    ---------------------------------------------OSAs----------------------------------------------
                    -->

                    <?php if($userDesignation == "OSAs" || $userDesignation == "Admin"): ?>
                    <div class="card-body">
                        <div class="card">
                            <div class="card-header">
                                IV. Student Development
                            </div>
                            <div class="card-body">
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspA. Student Organization</h6>
                                <table id="IVA" class="table">
                                    <thead>
                                        <th>Name of Organization</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $name_IVA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($organization_student->name); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>


                    <div class="card-body">
                        <div class="card">
                            <div class="card-header">
                                V. Research
                            </div>
                            <div class="card-body">
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspA. On-going Research/Study</h6>
                                <table id="VA" class="table">
                                    <thead>
                                        <th>Title of the Study</th>
                                        <th>Target Date of Completion</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $title_VA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ongoing_research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($ongoing_research->title); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($ongoing_research->date); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspB. Completed Research/Study</h6>
                                <table id="VB" class="table">
                                    <thead>
                                        <th>Title of the Study</th>
                                        <th>Date of Completion</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $title_VB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $completed_research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($completed_research->title); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($completed_research->date); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspC. Research Project Funded by Outside Agency</h6>
                                <table id="VC" class="table">
                                    <thead>
                                        <th>Title of the Study</th>
                                        <th>Sponsor Agency</th>
                                        <th>Date of Completion</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $title_VC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outside_research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($outside_research->title); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($outside_research->sponsor); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($outside_research->date); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                     <!-- 
                    --------------------------------------------Extension------------------------------------- 
                    -->

                    <?php if($userDesignation == "Extension" || $userDesignation == "Admin"): ?>
                    <div class="card-body">
                        <div class="card">
                            <div class="card-header">
                                VI. Extension
                            </div>
                            <div class="card-body">
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspA. Extension Projects</h6>
                                <table id="VIA" class="table">
                                    <thead>
                                        <th>Name of College/Campus Extension Project</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $name_VIA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extension_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($extension_project->name); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspB. Extension Activities</h6>
                                <table id="VIB" class="table">
                                    <thead>
                                        <th>Extension Activities</th>
                                        <th>Date of Extension Activity</th>
                                        <th>Extentionist (provide the name of the involved faculties)</th>
                                        <th>Total Number of Clientle/Beneficiaries</th>
                                        <th>Partner Agency (if applicable)</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $activity_VIB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extension_activities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($extension_activities->activity); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($extension_activities->date); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($extension_activities->extensionist); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($extension_activities->clientle); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($extension_activities->agency); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- 
                    ----------------------------------------------------EBA---------------------------------------------- 
                    -->

                    <?php if($userDesignation == "EBA" || $userDesignation == "Admin"): ?>
                    <div class="card-body">
                        <div class="card">
                            <div class="card-header">
                                VII. Linkages and Fund Generation
                            </div>
                            <div class="card-body">
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspA. Linkages</h6>
                                <table id="VIIA" class="table">
                                    <thead>
                                        <th>Agency</th>
                                        <th>Nature of Linkage (OJT Center, Immersion Partner, Funding Agency, Training Site, etc)</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $agency_VIIA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($linkages->agency); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($linkages->nature); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspB. Fund Generation</h6>
                                <table id="VIIB" class="table">
                                    <thead>
                                        <th>Income Generating Project</th>
                                        <th>Amount Generated</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $project_VIIB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fund_generation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($fund_generation->project); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($fund_generation->amount); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($userDesignation == "Custodian" || $userDesignation == "Admin"): ?>
                    <div class="card-body">
                        <div class="card">
                            <div class="card-header">
                                VIII. Infrastructure Development
                            </div>
                            <div class="card-body">
                                <br>
                                <h6 class="card-title">&nbsp&nbsp&nbspA. Linkages</h6>
                                <table id="VIIIA" class="table">
                                    <thead>
                                        <th>Infrastructure</th>
                                        <th>Percentage of Development</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $infrastructure_VIIIA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infrastructure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($infrastructure->infrastructure); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($infrastructure->percentage); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CvSU_Tanza_Report_System\resources\views/viewSpecificReport.blade.php ENDPATH**/ ?>