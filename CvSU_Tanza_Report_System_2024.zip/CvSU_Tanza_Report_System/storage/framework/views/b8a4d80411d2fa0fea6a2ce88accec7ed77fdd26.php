

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div class="card">
                <div class="card-header">
                    <li class="nav-item nav-link text-black"><?php echo e(__('Year and Quarter Management')); ?></li>
                </div>
                <div class="card-body">
                    <!-- <div class="hidden fixed top-0 right-0 sm:block"> -->
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><a class="btn btn-primary float-end" href="<?php echo e(route('add.year')); ?>" role="button"> Add Year</a></li>
                        </ul>
                    <!-- </div> -->

                    <?php if($years->isEmpty()): ?>
                        No registered faculty
                    <?php else: ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Year</th>
                            <th>Quarter</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($year->year); ?></td>
                            <td><?php echo e($year->quarter); ?></td>
                            <td>
                                <?php if($year->status == 'active'): ?>
                                    <p class="text-success fw-bold">ACTIVE</p>
                                <?php else: ?>
                                    <p class="text-secondary fw-bold">INACTIVE</p>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($year->status == 'inactive'): ?>
                                    <input class="btn btn-outline-success" type="button" onClick="updateYear(<?php echo e($year->year); ?>,<?php echo e($year->quarter); ?>)" value="Activate">
                                <?php else: ?>
                                    <input class="btn btn-outline-secondary" type="button" onClick="" value="Activate" disabled>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CvSU_Tanza_Report_System\resources\views/years.blade.php ENDPATH**/ ?>