<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\CvSU_Tanza_Report_System\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>