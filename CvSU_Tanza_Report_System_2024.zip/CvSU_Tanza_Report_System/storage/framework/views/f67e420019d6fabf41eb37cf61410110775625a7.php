

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div class="card">
                <div class="card-header">
                    <li class="nav-item nav-link text-black"><?php echo e(__('List of Faculties')); ?></li>
                </div>
                <div class="card-body">
                    <!-- <div class="hidden fixed top-0 right-0 sm:block"> -->
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><a class="btn btn-primary float-end" href="<?php echo e(route('register')); ?>" role="button"> Add Faculty</a></li>
                        </ul>
                        <?php if($users->isEmpty()): ?>
                            No registered faculty
                        <?php else: ?>
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Department</th>
                                <th>Designation</th>
                            </tr>
                            </thead>
                            <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                <div class="col">
                                    <select class="custom-select" id="dept<?php echo e($user->id); ?>" name="department">
                                        <?php if($user->department == 'DAS'): ?>
                                            <option selected value="DAS">Department of Arts and Sciences</option>
                                            <option value="DIT">Department of Information Technology</option>
                                            <option value="DOM">Department of Management</option>
                                            <option value="TED">Teacher Education Department</option>
                                            <option value="STAFF">Staff</option>
                                        <?php elseif($user->department == 'DIT'): ?>
                                            <option value="DAS">Department of Arts and Sciences</option>
                                            <option selected value="DIT">Department of Information Technology</option>
                                            <option value="DOM">Department of Management</option>
                                            <option value="TED">Teacher Education Department</option>
                                            <option value="STAFF">Staff</option>
                                        <?php elseif($user->department == 'DOM'): ?>
                                            <option value="DAS">Department of Arts and Sciences</option>
                                            <option value="DIT">Department of Information Technology</option>
                                            <option selected value="DOM">Department of Management</option>
                                            <option value="TED">Teacher Education Department</option>
                                            <option value="STAFF">Staff</option>
                                        <?php elseif($user->department == 'TED'): ?>
                                            <option value="DAS">Department of Arts and Sciences</option>
                                            <option value="DIT">Department of Information Technology</option>
                                            <option value="DOM">Department of Management</option>
                                            <option selected value="TED">Teacher Education Department</option>
                                            <option value="STAFF">Staff</option>
                                        <?php else: ?>
                                            <option value="DAS">Department of Arts and Sciences</option>
                                            <option value="DIT">Department of Information Technology</option>
                                            <option value="DOM">Department of Management</option>
                                            <option value="TED">Teacher Education Department</option>
                                            <option selected value="STAFF">Staff</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                </td>
                                <td>
                                <div class="col">
                                    <select class="custom-select" id="desig<?php echo e($user->id); ?>" name="designation">
                                        <option value="none">None</option>
                                        <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($designation->value == $user->designation): ?> 
                                                <option selected value="<?php echo e($designation->value); ?>"><?php echo e($designation->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($designation->value); ?>"><?php echo e($designation->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                </td>
                                <td>
                                    <input class="btn btn-outline-success" type="button" onClick='updateFaculty(<?php echo e($user->id); ?>)' value="Save">
                                    <a href="<?php echo e(route('delete.faculty', $user->id)); ?>" class="btn btn-outline-danger" role="button">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    <!-- </div> -->
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CvSU_Tanza_Report_System\resources\views/faculties.blade.php ENDPATH**/ ?>