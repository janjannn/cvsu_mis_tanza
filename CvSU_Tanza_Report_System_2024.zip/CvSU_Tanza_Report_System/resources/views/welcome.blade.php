@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="jumbotron" style="margin-top: 190px;">
                <h1 class="display-4">CvSU Tanza <br>Management Information <br>System</h1>
            </div>
        </div>
    </div>
</div>
@endsection
